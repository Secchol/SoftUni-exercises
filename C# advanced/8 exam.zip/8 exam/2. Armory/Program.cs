﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _2._Armory
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int matrixSize = int.Parse(Console.ReadLine());
            char[,] matrix = new char[matrixSize, matrixSize];
            int[] officerPosition = new int[matrixSize];
            for (int row = 0; row < matrixSize; row++)
            {
                char[] rowElements = Console.ReadLine().ToCharArray();
                for (int col = 0; col < matrixSize; col++)
                {
                    matrix[row, col] = rowElements[col];
                    if (matrix[row, col] == 'A')
                    {
                        officerPosition[0] = row;
                        officerPosition[1] = col;

                    }

                }
            }
            int goldCoinsPayed = 0;
            bool hasLeftArea = false;
            bool reachedGoldNeeded = false;
            while (!hasLeftArea && !reachedGoldNeeded)
            {
                string command = Console.ReadLine();
                int row = officerPosition[0];
                int col = officerPosition[1];
                matrix[row, col] = '-';
                if (command == "up" && IsValidIndex(matrix, row - 1, col))
                {
                    row--;

                }
                else if (command == "down" && IsValidIndex(matrix, row + 1, col))
                {
                    row++;

                }
                else if (command == "left" && IsValidIndex(matrix, row, col - 1))
                {
                    col--;

                }
                else if (command == "right" && IsValidIndex(matrix, row, col + 1))
                {
                    col++;

                }
                else
                {
                    hasLeftArea = true;


                }
                if (char.IsDigit(matrix[row, col]))
                {
                    goldCoinsPayed += int.Parse(matrix[row, col].ToString());

                }
                else if (matrix[row, col] == 'M')
                {
                    int[] nextMirrorIndices = new int[2];
                    matrix[row, col] = '-';
                    for (int i = 0; i < matrixSize; i++)
                    {

                        for (int j = 0; j < matrixSize; j++)
                        {

                            if (matrix[i, j] == 'M')
                            {
                                nextMirrorIndices[0] = i;
                                nextMirrorIndices[1] = j;

                            }

                        }
                    }
                    row = nextMirrorIndices[0];
                    col = nextMirrorIndices[1];
                }
                if (!hasLeftArea)
                {
                    matrix[row, col] = 'A';
                    officerPosition[0] = row;
                    officerPosition[1] = col;

                }
                if (goldCoinsPayed >= 65)
                {
                    reachedGoldNeeded = true;

                }
            }
            if (hasLeftArea)
            {
                Console.WriteLine("I do not need more swords!");


            }
            else
            {
                Console.WriteLine("Very nice swords, I will come back for more!");

            }
            Console.WriteLine($"The king paid {goldCoinsPayed} gold coins.");

            for (int row = 0; row < matrixSize; row++)
            {

                for (int col = 0; col < matrixSize; col++)
                {
                    Console.Write($"{matrix[row, col]}");

                }
                Console.WriteLine();
            }
        }
        public static bool IsValidIndex(char[,] matrix, int row, int col)
        {
            return row >= 0 && row < matrix.GetLength(0) && col >= 0 && col < matrix.GetLength(1);


        }
    }
}

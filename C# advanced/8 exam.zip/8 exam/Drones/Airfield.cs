﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace Drones
{
    public class Airfield
    {
        public List<Drone> Drones { get; set; }
        public string Name { get; set; }
        public int Capacity { get; set; }
        public double LandingStrip { get; set; }
        public int Count { get; private set; }

        public Airfield(string name, int capacity, double landingStrip)
        {
            Name = name;
            Capacity = capacity;
            LandingStrip = landingStrip;
            Drones = new List<Drone>();
        }
        public string AddDrone(Drone drone)
        {
            if (string.IsNullOrEmpty(drone.Name) || string.IsNullOrEmpty(drone.Brand) || drone.Range < 5 || drone.Range > 15)
            {
                return "Invalid drone.";


            }
            if (Drones.Count == Capacity)
            {
                return "Airfield is full.";

            }
            Drones.Add(drone);
            Count++;
            return $"Successfully added {drone.Name} to the airfield.";

        }
        public bool RemoveDrone(string name)
        {
            Drone drone = Drones.FirstOrDefault(x => x.Name == name);
            if (drone == null)
                return false;
            Drones.Remove(drone);
            Count--;
            return true;

        }
        public int RemoveDroneByBrand(string brand)
        {
            int dronesRemoved = Drones.RemoveAll(x => x.Brand == brand);
            Count -= dronesRemoved;
            return dronesRemoved;


        }
        public Drone FlyDrone(string name)
        {
            Drone drone = Drones.FirstOrDefault(x => x.Name == name);
            if (drone == null)
                return null;
            drone.Available = false;
            return drone;



        }
        public List<Drone> FlyDronesByRange(int range)
        {
            List<Drone> drones = Drones.Where(x => x.Range >= range).ToList();
            drones.ForEach(x => FlyDrone(x.Name));
            return drones;


        }
        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Drones available at {Name}:");
            foreach (Drone drone in Drones.Where(x => x.Available == true))
            {
                sb.AppendLine(drone.ToString());

            }
            return sb.ToString().TrimEnd();

        }
    }
}

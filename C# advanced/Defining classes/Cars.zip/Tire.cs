﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarManufacturer
{
    public class Tire
    {
        private int years;
        private double pressure;
        public int Year { get { return years; } set { years = value; } }
        public double Pressure { get { return pressure; } set { pressure = value; } }
        public Tire(int years, double pressure)
        {
            this.Year = years;
            this.Pressure = pressure;


        }
    }
}

﻿using System.Collections.Generic;
using System.Linq;
using System;
namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Tire[]> tiresInfo = new List<Tire[]>();
            string info = Console.ReadLine();
            while (info != "No more tires")
            {
                List<double> numbers = info.Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .Select(double.Parse)
                    .ToList();
                Tire[] tires = new Tire[numbers.Count / 2];
                int index = 0;
                for (int i = 0; i < numbers.Count; i += 2)
                {
                    int year = (int)numbers[i];
                    double pressure = numbers[i + 1];

                    Tire tire = new Tire((int)year, pressure);
                    tires[index] = tire;
                    index++;
                }
                tiresInfo.Add(tires);

                info = Console.ReadLine();
            }
            List<Engine> enginesInfo = new List<Engine>();
            info = Console.ReadLine();
            while (info != "Engines done")
            {
                double[] engines = info
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .Select(double.Parse)
                    .ToArray();
                Engine engine = new Engine((int)engines[0], engines[1]);
                enginesInfo.Add(engine);

                info = Console.ReadLine();
            }
            info = Console.ReadLine();
            List<Car> specialCars = new List<Car>();
            while (info != "Show special")
            {
                string[] carInfo = info.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string make = carInfo[0];
                string model = carInfo[1];
                int year = int.Parse(carInfo[2]);
                double fuelQuantity = double.Parse(carInfo[3]);
                double fuelConsumption = double.Parse(carInfo[4]);
                int engineIndex = int.Parse(carInfo[5]);
                int tiresIndex = int.Parse(carInfo[6]);
                double sum = 0;
                foreach (Tire tire in tiresInfo[tiresIndex])
                    sum += tire.Pressure;
                if (year >= 2017 && enginesInfo[engineIndex].HorsePower > 330 && sum >= 9 && sum <= 10)
                {
                    fuelQuantity -= 0.2 * fuelConsumption;
                    Car car = new Car(make, model, year, fuelQuantity, fuelConsumption, enginesInfo[engineIndex], tiresInfo[tiresIndex]);
                    specialCars.Add(car);
                }



                info = Console.ReadLine();
            }
            foreach (Car specialCar in specialCars)
            {
                Console.WriteLine($"Make: {specialCar.Make}");
                Console.WriteLine($"Model: {specialCar.Model}");
                Console.WriteLine($"Year: {specialCar.Year}");
                Console.WriteLine($"HorsePowers: {specialCar.Engine.HorsePower}");
                Console.WriteLine($"FuelQuantity: {specialCar.FuelQuantity}");


            }
        }
    }
}

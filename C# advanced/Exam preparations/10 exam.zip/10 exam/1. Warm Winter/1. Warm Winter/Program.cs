﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _1._Warm_Winter
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack<int> hats = new Stack<int>(Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray());

            Queue<int> scarves = new Queue<int>(Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray());
            List<int> sets = new List<int>();
            while (hats.Count > 0 && scarves.Count > 0)
            {
                int currentHat = hats.Pop();
                int currentScarf = scarves.Peek();
                if (currentHat > currentScarf)
                {
                    sets.Add(currentHat + currentScarf);
                    scarves.Dequeue();

                }
                else if (currentHat == currentScarf)
                {
                    scarves.Dequeue();
                    hats.Push(currentHat + 1);


                }


            }
            Console.WriteLine($"The most expensive set is: {sets.Max()}");
            Console.WriteLine(String.Join(" ", sets));
        }
    }
}

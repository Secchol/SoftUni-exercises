﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _2._Super_Mario
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int lives = int.Parse(Console.ReadLine());
            int rowsCount = int.Parse(Console.ReadLine());
            char[][] jaggedArray = new char[rowsCount][];
            int[] marioPosition = new int[2];
            for (int i = 0; i < rowsCount; i++)
            {
                char[] rowElements = Console.ReadLine().ToCharArray();
                jaggedArray[i] = rowElements;
                for (int j = 0; j < rowElements.Length; j++)
                {
                    if (rowElements[j] == 'M')
                    {
                        marioPosition[0] = i;
                        marioPosition[1] = j;

                    }
                }
            }

            while (true)
            {
                string[] commandsArray = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string direction = commandsArray[0];
                int enemyRow = int.Parse(commandsArray[1]);
                int enemyCol = int.Parse(commandsArray[2]);
                int row = marioPosition[0];
                int col = marioPosition[1];
                jaggedArray[row][col] = '-';
                jaggedArray[enemyRow][enemyCol] = 'B';
                if (row == enemyRow && col == enemyCol)
                    lives -= 2;
                lives--;
                if (direction == "W" && IsValidIndex(jaggedArray, row - 1, col))
                {
                    row--;


                }
                else if (direction == "S" && IsValidIndex(jaggedArray, row + 1, col))
                {
                    row++;


                }
                else if (direction == "A" && IsValidIndex(jaggedArray, row, col - 1))
                {
                    col--;


                }
                else if (direction == "D" && IsValidIndex(jaggedArray, row, col + 1))
                {
                    col++;


                }
                if (jaggedArray[row][col] == 'B')
                {
                    lives -= 2;

                }
                if (lives <= 0)
                {
                    jaggedArray[row][col] = 'X';
                    Console.WriteLine($"Mario died at {row};{col}.");
                    break;
                }
                else if (jaggedArray[row][col] == 'P')
                {
                    jaggedArray[row][col] = '-';
                    Console.WriteLine($"Mario has successfully saved the princess! Lives left: {lives}");
                    break;
                }
                jaggedArray[row][col] = 'M';
                marioPosition[0] = row;
                marioPosition[1] = col;

            }
            for (int i = 0; i < jaggedArray.Length; i++)
            {
                Console.WriteLine(String.Join("", jaggedArray[i]));
            }
        }
        public static bool IsValidIndex(char[][] jaggedArray, int row, int col)
        {
            return row >= 0 && row < jaggedArray.Length && col >= 0 && col < jaggedArray[row].Length;



        }
    }
}

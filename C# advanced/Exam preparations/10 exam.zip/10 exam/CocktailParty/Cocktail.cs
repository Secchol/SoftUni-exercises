﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace CocktailParty
{
    public class Cocktail
    {
        public List<Ingredient> Ingredients { get; set; }
        public string Name { get; set; }
        public int Capacity { get; set; }
        public int MaxAlcoholLevel { get; set; }
        public int CurrentAlcoholLevel { get; private set; }

        public Cocktail(string name, int capacity, int maxAlcoholLevel)
        {
            Name = name;
            Capacity = capacity;
            MaxAlcoholLevel = maxAlcoholLevel;
            Ingredients = new List<Ingredient>();
        }
        public void Add(Ingredient ingredient)
        {
            if (!Ingredients.Any(x => x.Name == ingredient.Name) && Ingredients.Count < Capacity && ingredient.Alcohol <= MaxAlcoholLevel)
            {
                Ingredients.Add(ingredient);
                CurrentAlcoholLevel += ingredient.Alcohol;

            }


        }
        public bool Remove(string name)
        {
            Ingredient ingredient = Ingredients.FirstOrDefault(x => x.Name == name);
            if (ingredient == null)
                return false;
            Ingredients.Remove(ingredient);
            CurrentAlcoholLevel -= ingredient.Alcohol;
            return true;


        }
        public Ingredient FindIngredient(string name)
        {
            return Ingredients.FirstOrDefault(x => x.Name == name);


        }
        public Ingredient GetMostAlcoholicIngredient()
        {
            int maxAlcohol = Ingredients.Max(x => x.Alcohol);
            return Ingredients.First(x => x.Alcohol == maxAlcohol);


        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Cocktail: {Name} - Current Alcohol Level: {CurrentAlcoholLevel}");
            foreach (Ingredient ingredient in Ingredients)
            {
                sb.AppendLine(ingredient.ToString());


            }
            return sb.ToString().TrimEnd();

        }
    }
}

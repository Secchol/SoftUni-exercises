﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _1._Meal_Plan
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<string> meals = new Queue<string>(Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries));
            Stack<int> calories = new Stack<int>(Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray());
            Dictionary<string, int> foodCalories = new Dictionary<string, int>();
            foodCalories.Add("salad", 350);
            foodCalories.Add("soup", 490);
            foodCalories.Add("pasta", 680);
            foodCalories.Add("steak", 790);
            int mealsCount = 0;
            while (meals.Count != 0 && calories.Count != 0)
            {
                int currentMealCalories = foodCalories[meals.Dequeue()];
                int dayCalories = calories.Pop();
                mealsCount++;
                if (dayCalories - currentMealCalories > 0)
                {

                    dayCalories -= currentMealCalories;
                    calories.Push(dayCalories);

                    

                }
                else if (dayCalories - currentMealCalories < 0)
                {

                    currentMealCalories -= dayCalories;
                    if (calories.Count > 0)
                    {
                        int lastDayCalories = calories.Pop();
                        calories.Push(lastDayCalories - currentMealCalories);
                        

                    }

                }
                


            }
            if (meals.Count == 0)
            {
                Console.WriteLine($"John had {mealsCount} meals.");
                Console.WriteLine($"For the next few days, he can eat {string.Join(", ", calories)} calories.");

            }
            else
            {
                Console.WriteLine($"John ate enough, he had {mealsCount} meals.");
                Console.WriteLine($"Meals left: {string.Join(", ", meals)}.");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _2._Truffle_Hunter
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int matrixSize = int.Parse(Console.ReadLine());
            char[,] matrix = new char[matrixSize, matrixSize];
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                char[] rowItems = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .Select(x => char.Parse(x)).ToArray();
                for (int col = 0; col < matrix.GetLength(0); col++)
                {
                    matrix[row, col] = rowItems[col];
                }
            }
            Dictionary<char, int> truffels = new Dictionary<char, int>();
            int boarTruffels = 0;
            truffels.Add('B', 0);
            truffels.Add('S', 0);
            truffels.Add('W', 0);
            string command = Console.ReadLine();
            while (command != "Stop the hunt")
            {
                string[] commandArray = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string action = commandArray[0];
                int row = int.Parse(commandArray[1]);
                int col = int.Parse(commandArray[2]);

                if (action == "Collect")
                {
                    if (matrix[row, col] == 'B' || matrix[row, col] == 'S' || matrix[row, col] == 'W')
                    {
                        truffels[matrix[row, col]]++;
                        matrix[row, col] = '-';

                    }



                }
                else if (action == "Wild_Boar")
                {
                    string direction = commandArray[3];
                    if (direction == "up")
                    {
                        for (int i = row; i >= 0; i -= 2)
                        {
                            if (matrix[i, col] == 'B' || matrix[i, col] == 'S' || matrix[i, col] == 'W')
                            {
                                boarTruffels++;
                                matrix[i, col] = '-';

                            }
                        }

                    }
                    else if (direction == "down")
                    {
                        for (int i = row; i < matrix.GetLength(0); i += 2)
                        {
                            if (matrix[i, col] == 'B' || matrix[i, col] == 'S' || matrix[i, col] == 'W')
                            {
                                boarTruffels++;
                                matrix[i, col] = '-';

                            }
                        }

                    }
                    else if (direction == "left")
                    {
                        for (int i = col; i >= 0; i -= 2)
                        {
                            if (matrix[row, i] == 'B' || matrix[row, i] == 'S' || matrix[row, i] == 'W')
                            {
                                boarTruffels++;
                                matrix[row, i] = '-';

                            }
                        }

                    }
                    else if (direction == "right")
                    {
                        for (int i = col; i < matrix.GetLength(1); i += 2)
                        {
                            if (matrix[row, i] == 'B' || matrix[row, i] == 'S' || matrix[row, i] == 'W')
                            {
                                boarTruffels++;
                                matrix[row, i] = '-';

                            }
                        }

                    }

                }

                command = Console.ReadLine();
            }
            Console.WriteLine($"Peter manages to harvest {truffels['B']} black, {truffels['S']} summer, and {truffels['W']} white truffles.");
            Console.WriteLine($"The wild boar has eaten {boarTruffels} truffles.");
            for (int row = 0; row < matrix.GetLength(0); row++)
            {

                for (int col = 0; col < matrix.GetLength(0); col++)
                {
                    Console.Write(matrix[row, col] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}

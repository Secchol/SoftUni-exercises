﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Zoo
{
    public class Zoo
    {
        public List<Animal> Animals { get; set; }
        public string Name { get; set; }
        public int Capacity { get; set; }
        public Zoo(string name, int capacity)
        {
            this.Name = name;
            this.Capacity = capacity;
            Animals = new List<Animal>();


        }
        public string AddAnimal(Animal animal)
        {
            if (animal == null || animal.Equals(" "))
                return "Invalid animal species.";
            else if (animal.Diet != "herbivore" && animal.Diet != "carnivore")
                return "Invalid animal diet.";
            else if (Animals.Count == Capacity)
                return "The zoo is full.";
            Animals.Add(animal);
            return $"Successfully added {animal.Species} to the zoo.";



        }
        public int RemoveAnimals(string species)
        {
            int count = Animals.RemoveAll(x => x.Species == species);
            return count;


        }
        public List<Animal> GetAnimalsByDiet(string diet)
        {
            List<Animal> animalsByDiet = Animals.Where(x => x.Diet == diet).ToList();
            return animalsByDiet;

        }
        public Animal GetAnimalByWeight(double weight)
        {
            return Animals.FirstOrDefault(x => x.Weight == weight);

        }
        public string GetAnimalCountByLength(double minimumLength, double maximumLength)
        {
            List<Animal> animalsByLength = Animals.Where(x => x.Length >= minimumLength && x.Length <= maximumLength).ToList();
            return $"There are {animalsByLength.Count} animals with a length between {minimumLength} and {maximumLength} meters.";





        }
    }
}

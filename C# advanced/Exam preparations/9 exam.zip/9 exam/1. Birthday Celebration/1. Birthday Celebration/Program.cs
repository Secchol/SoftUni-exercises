﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _1._Birthday_Celebration
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<int> guests = new Queue<int>(Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray());
            Stack<int> plates = new Stack<int>(Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray());
            int wastedFood = 0;
            while (guests.Count > 0 && plates.Count > 0)
            {
                int currentGuest = guests.Peek();
                int currentPlateFood = plates.Peek();
                if (currentPlateFood >= currentGuest)
                {
                    guests.Dequeue();
                    wastedFood += currentPlateFood - currentGuest;
                    plates.Pop();

                }
                else if (currentGuest > currentPlateFood)
                {
                    while (true)
                    {
                        if (plates.Count > 0)
                        {
                            currentPlateFood = plates.Pop();
                            if (currentPlateFood >= currentGuest)
                            {
                                guests.Dequeue();
                                wastedFood += currentPlateFood - currentGuest;
                                break;

                            }
                            else
                            {
                                currentGuest -= currentPlateFood;

                            }
                        }
                        else
                        {
                            break;

                        }

                    }

                }


            }
            if (guests.Count == 0)
            {
                Console.WriteLine($"Plates: {string.Join(" ", plates)}");

            }
            else
            {
                Console.WriteLine($"Guests: {string.Join(" ", guests)}");

            }


            Console.WriteLine($"Wasted grams of food: {wastedFood}");

        }
    }
}


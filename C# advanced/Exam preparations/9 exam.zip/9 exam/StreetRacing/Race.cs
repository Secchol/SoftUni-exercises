﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace StreetRacing
{
    public class Race
    {
        public List<Car> Participants { get; set; }
        //        •	Name: string
        //•	Type: string
        //•	Laps: int
        //•	Capacity: int - the maximum allowed number of participants in the race
        //•	MaxHorsePower: int - the maximum allowed Horse Power of a Car in the Race
        public string Name { get; set; }
        public string Type { get; set; }
        public int Laps { get; set; }
        public int Capacity { get; set; }
        public int MaxHorsePower { get; set; }
        public int Count { get; private set; }

        public Race(string name, string type, int laps, int capacity, int maxHorsePower)
        {
            Name = name;
            Type = type;
            Laps = laps;
            Capacity = capacity;
            MaxHorsePower = maxHorsePower;
            Participants = new List<Car>();
        }
        public void Add(Car car)
        {
            if (!Participants.Any(x => x.LicensePlate == car.LicensePlate) && Participants.Count < Capacity && car.HorsePower <= MaxHorsePower)
            {
                Participants.Add(car);
                Count++;


            }
        }
        public bool Remove(string licensePlate)
        {
            Car car = Participants.FirstOrDefault(x => x.LicensePlate == licensePlate);
            if (car == null)
                return false;
            Participants.Remove(car);
            Count--;
            return true;

        }

        public Car FindParticipant(string licensePlate)
        {
            return Participants.FirstOrDefault(x => x.LicensePlate == licensePlate);

        }
        public Car GetMostPowerfulCar()
        {
            if (Participants.Count == 0)
                return null;
            int maxHorsePower = Participants.Max(x => x.HorsePower);
            Car car = Participants.First(x => x.HorsePower == maxHorsePower);
            return car;

        }
        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Race: {Name} - Type: {Type} (Laps: {Laps})");
            foreach (Car car in Participants)
            {
                sb.AppendLine(car.ToString());

            }
            return sb.ToString().TrimEnd();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _2._The_Battle_of_the_Five_Armies
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int armor = int.Parse(Console.ReadLine());
            int rows = int.Parse(Console.ReadLine());
            char[][] jaggedArray = new char[rows][];
            int[] armyPosition = new int[2];
            for (int row = 0; row < rows; row++)
            {
                char[] rowElements = Console.ReadLine().ToCharArray();
                jaggedArray[row] = rowElements;
                for (int i = 0; i < rowElements.Length; i++)
                {
                    if (rowElements[i] == 'A')
                    {
                        armyPosition[0] = row;
                        armyPosition[1] = i;

                    }
                }
            }
            while (true)
            {
                string[] commandsArray = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string direction = commandsArray[0];
                int orcRow = int.Parse(commandsArray[1]);
                int orcCol = int.Parse(commandsArray[2]);
                jaggedArray[orcRow][orcCol] = 'O';
                int row = armyPosition[0];
                int col = armyPosition[1];
                if (orcRow == row && orcCol == col)
                {
                    armor -= 2;


                }
                armor--;
                if (direction == "up" && IsValidIndex(jaggedArray, row - 1, col))
                {
                    jaggedArray[row][col] = '-';
                    row--;



                }
                else if (direction == "down" && IsValidIndex(jaggedArray, row + 1, col))
                {
                    jaggedArray[row][col] = '-';
                    row++;


                }
                else if (direction == "left" && IsValidIndex(jaggedArray, row, col - 1))
                {
                    jaggedArray[row][col] = '-';
                    col--;


                }
                else if (direction == "right" && IsValidIndex(jaggedArray, row, col + 1))
                {
                    jaggedArray[row][col] = '-';
                    col++;


                }
                if (jaggedArray[row][col] == 'O')
                {
                    armor -= 2;
                    jaggedArray[row][col] = 'A';

                }
                if (armor <= 0)
                {
                    Console.WriteLine($"The army was defeated at {row};{col}.");
                    jaggedArray[row][col] = 'X';
                    break;

                }
                if (jaggedArray[row][col] == 'M')
                {
                    Console.WriteLine($"The army managed to free the Middle World! Armor left: {armor}");
                    jaggedArray[row][col] = '-';

                    break;

                }
                armyPosition[0] = row;
                armyPosition[1] = col;


            }
            for (int row = 0; row < jaggedArray.Length; row++)
            {
                Console.WriteLine(String.Join("", jaggedArray[row]));
            }
        }
        public static bool IsValidIndex(char[][] jaggedArray, int row, int col)
        {
            return row >= 0 && row < jaggedArray.Length && col >= 0 & col < jaggedArray[row].Length;

        }
    }
}

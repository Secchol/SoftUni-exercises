﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _2._Selling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int matrixSize = int.Parse(Console.ReadLine());
            char[,] matrix = new char[matrixSize, matrixSize];
            int[] playerPosition = new int[2];
            for (int row = 0; row < matrixSize; row++)
            {
                char[] rowElements = Console.ReadLine().ToCharArray();
                for (int col = 0; col < matrixSize; col++)
                {
                    matrix[row, col] = rowElements[col];
                    if (matrix[row, col] == 'S')
                    {
                        playerPosition[0] = row;
                        playerPosition[1] = col;

                    }
                }
            }

            int money = 0;
            while (true)
            {
                string command = Console.ReadLine();
                int row = playerPosition[0];
                int col = playerPosition[1];
                matrix[row, col] = '-';
                if (command == "up" && IsValidIndex(matrix, row - 1, col))
                {
                    row--;


                }
                else if (command == "down" && IsValidIndex(matrix, row + 1, col))
                {
                    row++;


                }
                else if (command == "left" && IsValidIndex(matrix, row, col - 1))
                {
                    col--;


                }
                else if (command == "right" && IsValidIndex(matrix, row, col + 1))
                {
                    col++;


                }
                else
                {
                    Console.WriteLine("Bad news, you are out of the bakery.");
                    matrix[row, col] = '-';

                    break;

                }

                if (char.IsDigit(matrix[row, col]))
                {
                    money += int.Parse(matrix[row, col].ToString());

                }
                else if (matrix[row, col] == 'O')
                {
                    matrix[row, col] = '-';
                    for (int i = 0; i < matrixSize; i++)
                    {

                        for (int j = 0; j < matrixSize; j++)
                        {
                            if (matrix[i, j] == 'O')
                            {
                                row = i;
                                col = j;

                            }
                        }
                    }

                }
                matrix[row, col] = 'S';
                playerPosition[0] = row;
                playerPosition[1] = col;
                if (money >= 50)
                {
                    Console.WriteLine("Good news! You succeeded in collecting enough money!");
                    break;

                }


            }
            Console.WriteLine($"Money: {money}");
            for (int row = 0; row < matrixSize; row++)
            {

                for (int col = 0; col < matrixSize; col++)
                {
                    Console.Write($"{matrix[row, col]}");
                }
                Console.WriteLine();
            }

        }
        public static bool IsValidIndex(char[,] matrix, int row, int col)
        {

            return row >= 0 && row < matrix.GetLength(0) && col >= 0 && col < matrix.GetLength(1);

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace BakeryOpenning
{
    public class Bakery
    {
        private List<Employee> data;
        public List<Employee> Data { get { return data; } set { data = value; } }
        public string Name { get; set; }
        public int Capacity { get; set; }
        public int Count { get; private set; }

        public Bakery(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            Data = new List<Employee>();
        }
        public void Add(Employee employee)
        {
            if (Data.Count < Capacity)
            {
                Data.Add(employee);
                Count++;
            }

        }
        public bool Remove(string name)
        {
            Employee employee = Data.FirstOrDefault(x => x.Name == name);
            if (employee == null)
                return false;
            Data.Remove(employee);
            Count--;
            return true;


        }
        public Employee GetOldestEmployee()
        {
            int maxAge = Data.Max(x => x.Age);
            return Data.First(x => x.Age == maxAge);


        }
        public Employee GetEmployee(string name)
        {
            return Data.First(x => x.Name == name);


        }
        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Employees working at Bakery {this.Name}:");
            foreach (var employee in Data)
            {
                sb.AppendLine(employee.ToString());

            }
            return sb.ToString().TrimEnd();


        }
    }
}

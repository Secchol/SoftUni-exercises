﻿using System;
using System.Linq;
using System.Collections.Generic;
namespace Stack
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string command = Console.ReadLine();
            string[] input = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string numbersString = string.Join("", input.Skip(1));
            int[] inputNumbers = numbersString.Split(",", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            MyStack<int> stack = new MyStack<int>(inputNumbers);
            
                while (command != "END")
                {
                    if (command == "Pop")
                    {
                    
                        stack.Pop();

                    }
                    else if (command == "Push")
                    {
                        numbersString = string.Join("", input.Skip(1));
                        inputNumbers = numbersString.Split(",", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
                        foreach (int number in inputNumbers)
                        {
                            stack.Push(number);

                        }

                    }

                    command = Console.ReadLine();
                    input = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                    command = input[0];
                }
            
            
            foreach (var element in stack)
            {
                Console.WriteLine(element);

            }
            foreach (var element in stack)
            {
                Console.WriteLine(element);

            }

        }
    }
}

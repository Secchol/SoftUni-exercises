﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Stack
{
    public class MyStack<T> : IEnumerable<T>
    {
        private List<T> list;
        public MyStack(IEnumerable<T> input)
        {

            list = input.Reverse().ToList();


        }
        public void Push(T element)
        {
            list.Insert(0, element);


        }
        public T Pop()
        {
            if (list.Count == 0)
            {
                Console.WriteLine("No elements");
                return default(T);

            }
            else
            {
                T element = list[0];
                list.RemoveAt(0);
                return element;
            }


        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < list.Count; i++)
            {
                yield return list[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}

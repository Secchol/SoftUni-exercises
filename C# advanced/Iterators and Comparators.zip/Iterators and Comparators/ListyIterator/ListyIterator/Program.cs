﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace ListyIterator
{
    public class StartUp
    {

        static void Main(string[] args)
        {
            List<string> input = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).Skip(1).ToList();
            ListyIterator<string> list = new ListyIterator<string>(input);
            string command = Console.ReadLine();
            try
            {
                while (command != "END")
                {
                    if (command == "HasNext")
                    {
                        Console.WriteLine(list.HasNext());


                    }
                    else if (command == "Move")
                    {
                        Console.WriteLine(list.Move());

                    }
                    else if (command == "Print")
                    {
                        list.Print();


                    }
                    else if (command == "PrintAll")
                    {
                        list.PrintAll();


                    }


                    command = Console.ReadLine();
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }

    }

}

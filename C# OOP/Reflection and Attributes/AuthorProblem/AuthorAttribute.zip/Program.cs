﻿using System;

namespace AuthorProblem
{
    [Author("Me")]
    public class StartUp
    {
        [Author("Not me")]
        static void Main(string[] args)
        {
            
        }
    }
}

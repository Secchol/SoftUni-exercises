﻿using System;

namespace CustomStack
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            StackOfStrings stackOfStrings = new StackOfStrings();
            Console.WriteLine(stackOfStrings.isEmpty());
            stackOfStrings.AddRange(new StackOfStrings());
        }
    }
}

﻿using System;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            DarkKnight dark = new DarkKnight("Bitch", 10);
        }
    }
}

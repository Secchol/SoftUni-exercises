﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IRecognisbale
    {
        string Id { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string command = Console.ReadLine();
            List<string> birthdates = new List<string>();
            while (command != "End")
            {
                string[] commandsArray = command.Split(' ',StringSplitOptions.RemoveEmptyEntries);
                string thing = commandsArray[0];
                if (thing == "Citizen" || thing == "Pet")
                {
                    birthdates.Add(commandsArray[commandsArray.Length - 1]);

                }
                command = Console.ReadLine();
            }
            string birthYear = Console.ReadLine();
            foreach (string birthdate in birthdates)
            {
                string[] splitBirthdate = birthdate.Split('/');
                if (splitBirthdate[2] == birthYear)
                {
                    Console.WriteLine(birthdate);

                }

            }
        }
    }
}

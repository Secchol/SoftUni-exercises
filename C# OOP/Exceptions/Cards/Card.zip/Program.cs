﻿using System;
using System.Collections.Generic;

namespace Cards
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] cardsInfo = Console.ReadLine().Split(", ", StringSplitOptions.RemoveEmptyEntries);
            List<Card> cards = new List<Card>();
            foreach (string card in cardsInfo)
            {
                string[] cardInfo = card.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string face = cardInfo[0];
                string suit = cardInfo[1];
                Card createdCard = CreateCard(face, suit);
                if (createdCard != null)
                {
                    cards.Add(createdCard);

                }


            }
            foreach (Card card in cards)
            {
                Console.Write(card.ToString() + " ");
                Console.WriteLine();

            }
        }
        public static Card CreateCard(string face, string suit)
        {
            try
            {
                Card card = new Card(face, suit);
                return card;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }


        }
    }
}
